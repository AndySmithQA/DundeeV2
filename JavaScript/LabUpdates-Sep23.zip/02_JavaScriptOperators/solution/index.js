// Aritmetic Operators
// console.log(5 + 5);
// console.log(5 * 10);
// console.log(10 % 3);
// console.log(5 + 10 / 2 * 5 - 10);
// console.log((6 + 10) / 2 * 5 - 10);

// Assignment Operators
// console.log(x = x + 1);
// console.log(x+= 1);
// console.log(x++);
// console.log(++x);

// Relational Operators
// console.log(5 > 3);
// console.log(3 != 3);
// console.log(3 <= 2 && 5 >2);
// console.log(!5>3);

// Mismatched Types
// console.log(5 + "5");
// console.log(5 + true);
// console.log(5 * "5");
// console.log(1 == true);
// console.log(1 === true);

